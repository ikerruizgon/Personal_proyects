package fugacolditz;

public class Guardia {
    int x;
    int y;
    public Guardia(int x, int y) {
        this.x = x;
        this.y = y;
    }
}